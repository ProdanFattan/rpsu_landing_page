export default function NoticeSection() {
    return (
      <div className="relative bg-section_back py-4 overflow-hidden">
        <div className="flex whitespace-nowrap animate-marquee">
          <span className="text-[#8b0000] text-lg ">
            ** RPSU will remain closed for unavoidable circumstances. ** &nbsp;&nbsp;
          </span>
          <span className="text-[#8b0000] text-lg ">
            ** RPSU will remain closed for unavoidable circumstances. ** &nbsp;&nbsp;
          </span>
          <span className="text-[#8b0000] text-lg ">
            ** RPSU will remain closed for unavoidable circumstances. ** &nbsp;&nbsp;
          </span>
        </div>
      </div>
    );
  }
  